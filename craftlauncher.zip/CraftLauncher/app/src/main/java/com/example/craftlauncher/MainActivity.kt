package com.example.craftlauncher

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { LauncherScreen() }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LauncherScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE) }

    var username by remember { mutableStateOf(prefs.getString("username", "Steve") ?: "Steve") }
    var version by remember { mutableStateOf(prefs.getString("version", VERSIONS.first()) ?: VERSIONS.first()) }
    var ramMb by remember { mutableFloatStateOf(prefs.getInt("ram", 2048).toFloat()) }
    var expanded by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("พร้อมเล่น") }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Craft Launcher", style = MaterialTheme.typography.headlineMedium)
        Text("Minecraft Java Edition", style = MaterialTheme.typography.bodyMedium)

        OutlinedTextField(
            value = username,
            onValueChange = { username = it.take(16) },
            label = { Text("ชื่อผู้เล่น") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )

        ExposedDropdownMenuBox(expanded, { expanded = it }) {
            OutlinedTextField(
                value = version,
                onValueChange = {},
                readOnly = true,
                label = { Text("เวอร์ชัน") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                modifier = Modifier.menuAnchor().fillMaxWidth()
            )
            ExposedDropdownMenu(expanded, { expanded = false }) {
                VERSIONS.forEach { v ->
                    DropdownMenuItem(text = { Text(v) }, onClick = { version = v; expanded = false })
                }
            }
        }

        Column(Modifier.fillMaxWidth()) {
            Text("RAM: ${ramMb.roundToInt()} MB")
            Slider(value = ramMb, onValueChange = { ramMb = it }, valueRange = 1024f..4096f, steps = 5)
        }

        Spacer(Modifier.weight(1f))
        Text(status, style = MaterialTheme.typography.bodySmall)

        Button(
            onClick = {
                prefs.edit()
                    .putString("username", username)
                    .putString("version", version)
                    .putInt("ram", ramMb.roundToInt())
                    .apply()
                status = "กำลังเริ่มเกม..."
                LaunchBridge.launch(
                    ctx,
                    LaunchConfig(username.ifBlank { "Steve" }, version, ramMb.roundToInt()),
                    onStatus = { status = it }
                )
            },
            modifier = Modifier.fillMaxWidth().height(56.dp)
        ) { Text("เล่น") }
    }
}

// Placeholder list: replace with Mojang's version manifest once downloading is implemented.
val VERSIONS = listOf("1.21.4", "1.20.1", "1.19.4", "1.16.5", "1.12.2", "1.8.9")
