package com.example.craftlauncher

import android.content.Context

data class LaunchConfig(
    val username: String,
    val version: String,
    val ramMb: Int
)

/**
 * This is the part that actually starts the game.
 *
 * Android has no built-in Java runtime, so this needs three things the UI alone
 * cannot provide:
 *   1. A bundled JRE built for Android (arm64) - e.g. the one from PojavLauncher (LGPL).
 *   2. A downloader for the version JSON, client jar, libraries and assets from Mojang.
 *   3. An OpenGL translation layer (e.g. GL4ES / ANGLE) so the game can render.
 *
 * Wire those in inside launch(). Until then it only reports a status message.
 * Note: a legitimate Microsoft/Mojang account login is required to play online.
 */
object LaunchBridge {
    fun launch(ctx: Context, config: LaunchConfig, onStatus: (String) -> Unit) {
        // TODO 1: download version manifest + files for config.version
        // TODO 2: start the bundled JRE with -Xmx${config.ramMb}M and the game's main class
        // TODO 3: pass --username ${config.username} and the auth token
        onStatus("ยังไม่ได้เชื่อม Java runtime (ดู LaunchBridge.kt)")
    }
}
